﻿namespace Hospital_Management_System_Application
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label appointment_Ref_NoLabel;
            System.Windows.Forms.Label first_NmaeLabel;
            System.Windows.Forms.Label middle_NameLabel;
            System.Windows.Forms.Label last_NameLabel;
            System.Windows.Forms.Label e_mail_AddressLabel;
            System.Windows.Forms.Label date_of_BirthLabel;
            System.Windows.Forms.Label contact_NoLabel;
            System.Windows.Forms.Label addressLabel;
            System.Windows.Forms.Label postal_CodeLabel;
            System.Windows.Forms.Label cityLabel;
            System.Windows.Forms.Label doctor_NameLabel;
            System.Windows.Forms.Label doctor_Ref_NoLabel;
            System.Windows.Forms.Label date_TimeLabel;
            System.Windows.Forms.Label label4;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label5;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label genderLabel;
            System.Windows.Forms.Label area_CodeLabel;
            System.Windows.Forms.Label marital_StatusLabel;
            System.Windows.Forms.Label countryLabel;
            System.Windows.Forms.Label stateLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.hospitalDataSet = new Hospital_Management_System_Application.HospitalDataSet();
            this.appointmentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.appointmentTableAdapter = new Hospital_Management_System_Application.HospitalDataSetTableAdapters.AppointmentTableAdapter();
            this.tableAdapterManager = new Hospital_Management_System_Application.HospitalDataSetTableAdapters.TableAdapterManager();
            this.appointment_Ref_NoTextBox = new System.Windows.Forms.TextBox();
            this.first_NmaeTextBox = new System.Windows.Forms.TextBox();
            this.middle_NameTextBox = new System.Windows.Forms.TextBox();
            this.last_NameTextBox = new System.Windows.Forms.TextBox();
            this.e_mail_AddressTextBox = new System.Windows.Forms.TextBox();
            this.date_of_BirthDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.contact_NoTextBox = new System.Windows.Forms.TextBox();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.postal_CodeTextBox = new System.Windows.Forms.TextBox();
            this.cityTextBox = new System.Windows.Forms.TextBox();
            this.doctor_NameTextBox = new System.Windows.Forms.TextBox();
            this.doctor_Ref_NoTextBox = new System.Windows.Forms.TextBox();
            this.date_TimeDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.appointmentDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnClose = new System.Windows.Forms.Button();
            this.genderComboBox = new System.Windows.Forms.ComboBox();
            this.area_CodeComboBox = new System.Windows.Forms.ComboBox();
            this.marital_StatusComboBox = new System.Windows.Forms.ComboBox();
            this.comboBoxCountry1 = new System.Windows.Forms.ComboBox();
            this.comboBoxstate1 = new System.Windows.Forms.ComboBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.btnX = new System.Windows.Forms.Button();
            this.btnMinimise = new System.Windows.Forms.Button();
            this.appointment1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            appointment_Ref_NoLabel = new System.Windows.Forms.Label();
            first_NmaeLabel = new System.Windows.Forms.Label();
            middle_NameLabel = new System.Windows.Forms.Label();
            last_NameLabel = new System.Windows.Forms.Label();
            e_mail_AddressLabel = new System.Windows.Forms.Label();
            date_of_BirthLabel = new System.Windows.Forms.Label();
            contact_NoLabel = new System.Windows.Forms.Label();
            addressLabel = new System.Windows.Forms.Label();
            postal_CodeLabel = new System.Windows.Forms.Label();
            cityLabel = new System.Windows.Forms.Label();
            doctor_NameLabel = new System.Windows.Forms.Label();
            doctor_Ref_NoLabel = new System.Windows.Forms.Label();
            date_TimeLabel = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            genderLabel = new System.Windows.Forms.Label();
            area_CodeLabel = new System.Windows.Forms.Label();
            marital_StatusLabel = new System.Windows.Forms.Label();
            countryLabel = new System.Windows.Forms.Label();
            stateLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.hospitalDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appointmentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appointmentDataGridView)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appointment1BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // appointment_Ref_NoLabel
            // 
            appointment_Ref_NoLabel.AutoSize = true;
            appointment_Ref_NoLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            appointment_Ref_NoLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            appointment_Ref_NoLabel.Font = new System.Drawing.Font("Segoe Marker", 12.85714F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            appointment_Ref_NoLabel.Location = new System.Drawing.Point(153, 89);
            appointment_Ref_NoLabel.Name = "appointment_Ref_NoLabel";
            appointment_Ref_NoLabel.Size = new System.Drawing.Size(248, 37);
            appointment_Ref_NoLabel.TabIndex = 1;
            appointment_Ref_NoLabel.Text = "Appointment Ref No:";
            // 
            // first_NmaeLabel
            // 
            first_NmaeLabel.AutoSize = true;
            first_NmaeLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            first_NmaeLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            first_NmaeLabel.Font = new System.Drawing.Font("Segoe Marker", 12.85714F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            first_NmaeLabel.Location = new System.Drawing.Point(262, 142);
            first_NmaeLabel.Name = "first_NmaeLabel";
            first_NmaeLabel.Size = new System.Drawing.Size(141, 37);
            first_NmaeLabel.TabIndex = 3;
            first_NmaeLabel.Text = "First Nmae:";
            // 
            // middle_NameLabel
            // 
            middle_NameLabel.AutoSize = true;
            middle_NameLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            middle_NameLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            middle_NameLabel.Font = new System.Drawing.Font("Segoe Marker", 12.85714F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            middle_NameLabel.Location = new System.Drawing.Point(234, 195);
            middle_NameLabel.Name = "middle_NameLabel";
            middle_NameLabel.Size = new System.Drawing.Size(168, 37);
            middle_NameLabel.TabIndex = 5;
            middle_NameLabel.Text = "Middle Name:";
            // 
            // last_NameLabel
            // 
            last_NameLabel.AutoSize = true;
            last_NameLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            last_NameLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            last_NameLabel.Font = new System.Drawing.Font("Segoe Marker", 12.85714F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            last_NameLabel.Location = new System.Drawing.Point(267, 248);
            last_NameLabel.Name = "last_NameLabel";
            last_NameLabel.Size = new System.Drawing.Size(136, 37);
            last_NameLabel.TabIndex = 7;
            last_NameLabel.Text = "Last Name:";
            // 
            // e_mail_AddressLabel
            // 
            e_mail_AddressLabel.AutoSize = true;
            e_mail_AddressLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            e_mail_AddressLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            e_mail_AddressLabel.Font = new System.Drawing.Font("Segoe Marker", 12.85714F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            e_mail_AddressLabel.Location = new System.Drawing.Point(215, 301);
            e_mail_AddressLabel.Name = "e_mail_AddressLabel";
            e_mail_AddressLabel.Size = new System.Drawing.Size(185, 37);
            e_mail_AddressLabel.TabIndex = 9;
            e_mail_AddressLabel.Text = "E-mail Address:";
            // 
            // date_of_BirthLabel
            // 
            date_of_BirthLabel.AutoSize = true;
            date_of_BirthLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            date_of_BirthLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            date_of_BirthLabel.Font = new System.Drawing.Font("Segoe Marker", 12.85714F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            date_of_BirthLabel.Location = new System.Drawing.Point(238, 407);
            date_of_BirthLabel.Name = "date_of_BirthLabel";
            date_of_BirthLabel.Size = new System.Drawing.Size(164, 37);
            date_of_BirthLabel.TabIndex = 13;
            date_of_BirthLabel.Text = "Date of Birth:";
            // 
            // contact_NoLabel
            // 
            contact_NoLabel.AutoSize = true;
            contact_NoLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            contact_NoLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            contact_NoLabel.Font = new System.Drawing.Font("Segoe Marker", 12.85714F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            contact_NoLabel.Location = new System.Drawing.Point(259, 513);
            contact_NoLabel.Name = "contact_NoLabel";
            contact_NoLabel.Size = new System.Drawing.Size(146, 37);
            contact_NoLabel.TabIndex = 17;
            contact_NoLabel.Text = "Contact No:";
            // 
            // addressLabel
            // 
            addressLabel.AutoSize = true;
            addressLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            addressLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            addressLabel.Font = new System.Drawing.Font("Segoe Marker", 12.85714F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            addressLabel.Location = new System.Drawing.Point(295, 619);
            addressLabel.Name = "addressLabel";
            addressLabel.Size = new System.Drawing.Size(108, 37);
            addressLabel.TabIndex = 21;
            addressLabel.Text = "Address:";
            // 
            // postal_CodeLabel
            // 
            postal_CodeLabel.AutoSize = true;
            postal_CodeLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            postal_CodeLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            postal_CodeLabel.Font = new System.Drawing.Font("Segoe Marker", 12.85714F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            postal_CodeLabel.Location = new System.Drawing.Point(252, 672);
            postal_CodeLabel.Name = "postal_CodeLabel";
            postal_CodeLabel.Size = new System.Drawing.Size(151, 37);
            postal_CodeLabel.TabIndex = 23;
            postal_CodeLabel.Text = "Postal Code:";
            // 
            // cityLabel
            // 
            cityLabel.AutoSize = true;
            cityLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            cityLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            cityLabel.Font = new System.Drawing.Font("Segoe Marker", 12.85714F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            cityLabel.Location = new System.Drawing.Point(340, 831);
            cityLabel.Name = "cityLabel";
            cityLabel.Size = new System.Drawing.Size(65, 37);
            cityLabel.TabIndex = 29;
            cityLabel.Text = "City:";
            // 
            // doctor_NameLabel
            // 
            doctor_NameLabel.AutoSize = true;
            doctor_NameLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            doctor_NameLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            doctor_NameLabel.Font = new System.Drawing.Font("Segoe Marker", 12.85714F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            doctor_NameLabel.Location = new System.Drawing.Point(231, 884);
            doctor_NameLabel.Name = "doctor_NameLabel";
            doctor_NameLabel.Size = new System.Drawing.Size(168, 37);
            doctor_NameLabel.TabIndex = 31;
            doctor_NameLabel.Text = "Doctor Name:";
            // 
            // doctor_Ref_NoLabel
            // 
            doctor_Ref_NoLabel.AutoSize = true;
            doctor_Ref_NoLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            doctor_Ref_NoLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            doctor_Ref_NoLabel.Font = new System.Drawing.Font("Segoe Marker", 12.85714F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            doctor_Ref_NoLabel.Location = new System.Drawing.Point(219, 937);
            doctor_Ref_NoLabel.Name = "doctor_Ref_NoLabel";
            doctor_Ref_NoLabel.Size = new System.Drawing.Size(180, 37);
            doctor_Ref_NoLabel.TabIndex = 33;
            doctor_Ref_NoLabel.Text = "Doctor Ref No:";
            // 
            // date_TimeLabel
            // 
            date_TimeLabel.AutoSize = true;
            date_TimeLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            date_TimeLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            date_TimeLabel.Font = new System.Drawing.Font("Segoe Marker", 12.85714F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            date_TimeLabel.Location = new System.Drawing.Point(264, 990);
            date_TimeLabel.Name = "date_TimeLabel";
            date_TimeLabel.Size = new System.Drawing.Size(133, 37);
            date_TimeLabel.TabIndex = 35;
            date_TimeLabel.Text = "Date Time:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = System.Drawing.Color.Transparent;
            label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            label4.Font = new System.Drawing.Font("Segoe Marker", 21.85714F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label4.ForeColor = System.Drawing.Color.Indigo;
            label4.Location = new System.Drawing.Point(7, 274);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(149, 59);
            label4.TabIndex = 34;
            label4.Text = "Love....";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = System.Drawing.Color.Transparent;
            label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            label3.Font = new System.Drawing.Font("Segoe Marker", 21.85714F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label3.ForeColor = System.Drawing.Color.Indigo;
            label3.Location = new System.Drawing.Point(13, 110);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(148, 59);
            label3.TabIndex = 33;
            label3.Text = "Care....";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = System.Drawing.Color.Transparent;
            label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            label5.Font = new System.Drawing.Font("Segoe Marker", 21.85714F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label5.ForeColor = System.Drawing.Color.Indigo;
            label5.Location = new System.Drawing.Point(13, 195);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(83, 59);
            label5.TabIndex = 35;
            label5.Text = "We";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = System.Drawing.Color.Transparent;
            label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            label2.Font = new System.Drawing.Font("Segoe Marker", 21.85714F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label2.ForeColor = System.Drawing.Color.Indigo;
            label2.Location = new System.Drawing.Point(13, 36);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(83, 59);
            label2.TabIndex = 32;
            label2.Text = "We";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = System.Drawing.Color.Transparent;
            label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            label1.Font = new System.Drawing.Font("Segoe Marker", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label1.ForeColor = System.Drawing.Color.Indigo;
            label1.Location = new System.Drawing.Point(1314, 48);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(619, 98);
            label1.TabIndex = 47;
            label1.Text = "Make Appointment";
            // 
            // genderLabel
            // 
            genderLabel.AutoSize = true;
            genderLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            genderLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            genderLabel.Font = new System.Drawing.Font("Segoe Marker", 12.85714F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            genderLabel.Location = new System.Drawing.Point(304, 354);
            genderLabel.Name = "genderLabel";
            genderLabel.Size = new System.Drawing.Size(102, 37);
            genderLabel.TabIndex = 48;
            genderLabel.Text = "Gender:";
            // 
            // area_CodeLabel
            // 
            area_CodeLabel.AutoSize = true;
            area_CodeLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            area_CodeLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            area_CodeLabel.Font = new System.Drawing.Font("Segoe Marker", 12.85714F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            area_CodeLabel.Location = new System.Drawing.Point(269, 460);
            area_CodeLabel.Name = "area_CodeLabel";
            area_CodeLabel.Size = new System.Drawing.Size(134, 37);
            area_CodeLabel.TabIndex = 49;
            area_CodeLabel.Text = "Area Code:";
            // 
            // marital_StatusLabel
            // 
            marital_StatusLabel.AutoSize = true;
            marital_StatusLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            marital_StatusLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            marital_StatusLabel.Font = new System.Drawing.Font("Segoe Marker", 12.85714F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            marital_StatusLabel.Location = new System.Drawing.Point(226, 566);
            marital_StatusLabel.Name = "marital_StatusLabel";
            marital_StatusLabel.Size = new System.Drawing.Size(174, 37);
            marital_StatusLabel.TabIndex = 50;
            marital_StatusLabel.Text = "Marital Status:";
            // 
            // countryLabel
            // 
            countryLabel.AutoSize = true;
            countryLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            countryLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            countryLabel.Font = new System.Drawing.Font("Segoe Marker", 12.85714F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            countryLabel.Location = new System.Drawing.Point(294, 725);
            countryLabel.Name = "countryLabel";
            countryLabel.Size = new System.Drawing.Size(110, 37);
            countryLabel.TabIndex = 51;
            countryLabel.Text = "Country:";
            // 
            // stateLabel
            // 
            stateLabel.AutoSize = true;
            stateLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            stateLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            stateLabel.Font = new System.Drawing.Font("Segoe Marker", 12.85714F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            stateLabel.Location = new System.Drawing.Point(328, 778);
            stateLabel.Name = "stateLabel";
            stateLabel.Size = new System.Drawing.Size(77, 37);
            stateLabel.TabIndex = 52;
            stateLabel.Text = "State:";
            // 
            // hospitalDataSet
            // 
            this.hospitalDataSet.DataSetName = "HospitalDataSet";
            this.hospitalDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // appointmentBindingSource
            // 
            this.appointmentBindingSource.DataMember = "Appointment";
            this.appointmentBindingSource.DataSource = this.hospitalDataSet;
            // 
            // appointmentTableAdapter
            // 
            this.appointmentTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.AppointmentTableAdapter = this.appointmentTableAdapter;
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.DoctorTableAdapter = null;
            this.tableAdapterManager.MedicineTableAdapter = null;
            this.tableAdapterManager.NurseTableAdapter = null;
            this.tableAdapterManager.PatientTableAdapter = null;
            this.tableAdapterManager.PaymentTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Hospital_Management_System_Application.HospitalDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // appointment_Ref_NoTextBox
            // 
            this.appointment_Ref_NoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appointmentBindingSource, "Appointment_Ref_No", true));
            this.appointment_Ref_NoTextBox.Font = new System.Drawing.Font("Segoe Marker", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.appointment_Ref_NoTextBox.Location = new System.Drawing.Point(491, 87);
            this.appointment_Ref_NoTextBox.MaxLength = 4;
            this.appointment_Ref_NoTextBox.Name = "appointment_Ref_NoTextBox";
            this.appointment_Ref_NoTextBox.Size = new System.Drawing.Size(250, 40);
            this.appointment_Ref_NoTextBox.TabIndex = 2;
            this.appointment_Ref_NoTextBox.TextChanged += new System.EventHandler(this.appointment_Ref_NoTextBox_TextChanged);
            this.appointment_Ref_NoTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress22);
            // 
            // first_NmaeTextBox
            // 
            this.first_NmaeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appointmentBindingSource, "First_Nmae", true));
            this.first_NmaeTextBox.Font = new System.Drawing.Font("Segoe Marker", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.first_NmaeTextBox.Location = new System.Drawing.Point(491, 140);
            this.first_NmaeTextBox.Name = "first_NmaeTextBox";
            this.first_NmaeTextBox.Size = new System.Drawing.Size(250, 40);
            this.first_NmaeTextBox.TabIndex = 4;
            this.first_NmaeTextBox.TextChanged += new System.EventHandler(this.first_NmaeTextBox_TextChanged);
            this.first_NmaeTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KP1);
            // 
            // middle_NameTextBox
            // 
            this.middle_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appointmentBindingSource, "Middle_Name", true));
            this.middle_NameTextBox.Font = new System.Drawing.Font("Segoe Marker", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.middle_NameTextBox.Location = new System.Drawing.Point(490, 193);
            this.middle_NameTextBox.Name = "middle_NameTextBox";
            this.middle_NameTextBox.Size = new System.Drawing.Size(250, 40);
            this.middle_NameTextBox.TabIndex = 6;
            this.middle_NameTextBox.TextChanged += new System.EventHandler(this.middle_NameTextBox_TextChanged);
            this.middle_NameTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KP2);
            // 
            // last_NameTextBox
            // 
            this.last_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appointmentBindingSource, "Last_Name", true));
            this.last_NameTextBox.Font = new System.Drawing.Font("Segoe Marker", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.last_NameTextBox.Location = new System.Drawing.Point(490, 246);
            this.last_NameTextBox.Name = "last_NameTextBox";
            this.last_NameTextBox.Size = new System.Drawing.Size(250, 40);
            this.last_NameTextBox.TabIndex = 8;
            this.last_NameTextBox.TextChanged += new System.EventHandler(this.last_NameTextBox_TextChanged);
            this.last_NameTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KP3);
            // 
            // e_mail_AddressTextBox
            // 
            this.e_mail_AddressTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appointmentBindingSource, "E-mail_Address", true));
            this.e_mail_AddressTextBox.Font = new System.Drawing.Font("Segoe Marker", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.e_mail_AddressTextBox.Location = new System.Drawing.Point(489, 299);
            this.e_mail_AddressTextBox.Name = "e_mail_AddressTextBox";
            this.e_mail_AddressTextBox.Size = new System.Drawing.Size(250, 40);
            this.e_mail_AddressTextBox.TabIndex = 10;
            this.e_mail_AddressTextBox.TextChanged += new System.EventHandler(this.e_mail_AddressTextBox_TextChanged);
            // 
            // date_of_BirthDateTimePicker
            // 
            this.date_of_BirthDateTimePicker.Cursor = System.Windows.Forms.Cursors.Default;
            this.date_of_BirthDateTimePicker.CustomFormat = "dd-MM-yyyy";
            this.date_of_BirthDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.appointmentBindingSource, "Date_of_Birth", true));
            this.date_of_BirthDateTimePicker.Font = new System.Drawing.Font("Segoe Marker", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date_of_BirthDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date_of_BirthDateTimePicker.Location = new System.Drawing.Point(488, 406);
            this.date_of_BirthDateTimePicker.Name = "date_of_BirthDateTimePicker";
            this.date_of_BirthDateTimePicker.Size = new System.Drawing.Size(250, 40);
            this.date_of_BirthDateTimePicker.TabIndex = 14;
            this.date_of_BirthDateTimePicker.ValueChanged += new System.EventHandler(this.date_of_BirthDateTimePicker_ValueChanged);
            // 
            // contact_NoTextBox
            // 
            this.contact_NoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appointmentBindingSource, "Contact_No", true));
            this.contact_NoTextBox.Font = new System.Drawing.Font("Segoe Marker", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contact_NoTextBox.Location = new System.Drawing.Point(487, 513);
            this.contact_NoTextBox.MaxLength = 10;
            this.contact_NoTextBox.Name = "contact_NoTextBox";
            this.contact_NoTextBox.Size = new System.Drawing.Size(250, 40);
            this.contact_NoTextBox.TabIndex = 18;
            this.contact_NoTextBox.TextChanged += new System.EventHandler(this.contact_NoTextBox_TextChanged);
            this.contact_NoTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPr);
            // 
            // addressTextBox
            // 
            this.addressTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appointmentBindingSource, "Address", true));
            this.addressTextBox.Font = new System.Drawing.Font("Segoe Marker", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addressTextBox.Location = new System.Drawing.Point(488, 620);
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(250, 40);
            this.addressTextBox.TabIndex = 22;
            this.addressTextBox.TextChanged += new System.EventHandler(this.addressTextBox_TextChanged);
            // 
            // postal_CodeTextBox
            // 
            this.postal_CodeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appointmentBindingSource, "Postal_Code", true));
            this.postal_CodeTextBox.Font = new System.Drawing.Font("Segoe Marker", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.postal_CodeTextBox.Location = new System.Drawing.Point(488, 673);
            this.postal_CodeTextBox.MaxLength = 6;
            this.postal_CodeTextBox.Name = "postal_CodeTextBox";
            this.postal_CodeTextBox.Size = new System.Drawing.Size(250, 40);
            this.postal_CodeTextBox.TabIndex = 24;
            this.postal_CodeTextBox.TextChanged += new System.EventHandler(this.postal_CodeTextBox_TextChanged);
            this.postal_CodeTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress1);
            // 
            // cityTextBox
            // 
            this.cityTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appointmentBindingSource, "City", true));
            this.cityTextBox.Font = new System.Drawing.Font("Segoe Marker", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cityTextBox.Location = new System.Drawing.Point(487, 833);
            this.cityTextBox.Name = "cityTextBox";
            this.cityTextBox.Size = new System.Drawing.Size(250, 40);
            this.cityTextBox.TabIndex = 30;
            this.cityTextBox.TextChanged += new System.EventHandler(this.cityTextBox_TextChanged);
            this.cityTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KP8);
            // 
            // doctor_NameTextBox
            // 
            this.doctor_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appointmentBindingSource, "Doctor_Name", true));
            this.doctor_NameTextBox.Font = new System.Drawing.Font("Segoe Marker", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.doctor_NameTextBox.Location = new System.Drawing.Point(487, 885);
            this.doctor_NameTextBox.Name = "doctor_NameTextBox";
            this.doctor_NameTextBox.Size = new System.Drawing.Size(250, 40);
            this.doctor_NameTextBox.TabIndex = 32;
            this.doctor_NameTextBox.TextChanged += new System.EventHandler(this.doctor_NameTextBox_TextChanged);
            this.doctor_NameTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KP9);
            // 
            // doctor_Ref_NoTextBox
            // 
            this.doctor_Ref_NoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appointmentBindingSource, "Doctor_Ref_No", true));
            this.doctor_Ref_NoTextBox.Font = new System.Drawing.Font("Segoe Marker", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.doctor_Ref_NoTextBox.Location = new System.Drawing.Point(486, 937);
            this.doctor_Ref_NoTextBox.MaxLength = 4;
            this.doctor_Ref_NoTextBox.Name = "doctor_Ref_NoTextBox";
            this.doctor_Ref_NoTextBox.Size = new System.Drawing.Size(250, 40);
            this.doctor_Ref_NoTextBox.TabIndex = 34;
            this.doctor_Ref_NoTextBox.TextChanged += new System.EventHandler(this.doctor_Ref_NoTextBox_TextChanged);
            this.doctor_Ref_NoTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPress2);
            // 
            // date_TimeDateTimePicker
            // 
            this.date_TimeDateTimePicker.CustomFormat = "dd-MM-yyyy hh:mm";
            this.date_TimeDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.appointmentBindingSource, "Date_Time", true));
            this.date_TimeDateTimePicker.Font = new System.Drawing.Font("Segoe Marker", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date_TimeDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date_TimeDateTimePicker.Location = new System.Drawing.Point(485, 989);
            this.date_TimeDateTimePicker.Name = "date_TimeDateTimePicker";
            this.date_TimeDateTimePicker.Size = new System.Drawing.Size(250, 40);
            this.date_TimeDateTimePicker.TabIndex = 36;
            this.date_TimeDateTimePicker.ValueChanged += new System.EventHandler(this.date_TimeDateTimePicker_ValueChanged);
            // 
            // appointmentDataGridView
            // 
            this.appointmentDataGridView.AutoGenerateColumns = false;
            this.appointmentDataGridView.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.appointmentDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.appointmentDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18});
            this.appointmentDataGridView.DataSource = this.appointmentBindingSource;
            this.appointmentDataGridView.Location = new System.Drawing.Point(980, 194);
            this.appointmentDataGridView.Name = "appointmentDataGridView";
            this.appointmentDataGridView.RowTemplate.Height = 31;
            this.appointmentDataGridView.Size = new System.Drawing.Size(979, 596);
            this.appointmentDataGridView.TabIndex = 37;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Appointment_Ref_No";
            this.dataGridViewTextBoxColumn1.HeaderText = "Appointment_Ref_No";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "First_Nmae";
            this.dataGridViewTextBoxColumn2.HeaderText = "First_Nmae";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Middle_Name";
            this.dataGridViewTextBoxColumn3.HeaderText = "Middle_Name";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Last_Name";
            this.dataGridViewTextBoxColumn4.HeaderText = "Last_Name";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "E-mail_Address";
            this.dataGridViewTextBoxColumn5.HeaderText = "E-mail_Address";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Gender";
            this.dataGridViewTextBoxColumn6.HeaderText = "Gender";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Date_of_Birth";
            this.dataGridViewTextBoxColumn7.HeaderText = "Date_of_Birth";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Area_Code";
            this.dataGridViewTextBoxColumn8.HeaderText = "Area_Code";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Contact_No";
            this.dataGridViewTextBoxColumn9.HeaderText = "Contact_No";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Marital_Status";
            this.dataGridViewTextBoxColumn10.HeaderText = "Marital_Status";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Address";
            this.dataGridViewTextBoxColumn11.HeaderText = "Address";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Postal_Code";
            this.dataGridViewTextBoxColumn12.HeaderText = "Postal_Code";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "Country";
            this.dataGridViewTextBoxColumn13.HeaderText = "Country";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "State";
            this.dataGridViewTextBoxColumn14.HeaderText = "State";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "City";
            this.dataGridViewTextBoxColumn15.HeaderText = "City";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "Doctor_Name";
            this.dataGridViewTextBoxColumn16.HeaderText = "Doctor_Name";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "Doctor_Ref_No";
            this.dataGridViewTextBoxColumn17.HeaderText = "Doctor_Ref_No";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "Date_Time";
            this.dataGridViewTextBoxColumn18.HeaderText = "Date_Time";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Indigo;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("Segoe Marker", 14.14286F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(1826, 905);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(120, 69);
            this.btnExit.TabIndex = 45;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.Indigo;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Segoe Marker", 14.14286F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(1510, 905);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(122, 69);
            this.btnSave.TabIndex = 46;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.BackColor = System.Drawing.Color.Indigo;
            this.btnPrevious.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrevious.Font = new System.Drawing.Font("Segoe Marker", 14.14286F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrevious.ForeColor = System.Drawing.Color.White;
            this.btnPrevious.Location = new System.Drawing.Point(1309, 905);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(167, 69);
            this.btnPrevious.TabIndex = 43;
            this.btnPrevious.Text = "Previous";
            this.btnPrevious.UseVisualStyleBackColor = false;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnNext
            // 
            this.btnNext.BackColor = System.Drawing.Color.Indigo;
            this.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNext.Font = new System.Drawing.Font("Segoe Marker", 14.14286F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext.ForeColor = System.Drawing.Color.White;
            this.btnNext.Location = new System.Drawing.Point(1160, 905);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(115, 69);
            this.btnNext.TabIndex = 42;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Indigo;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Segoe Marker", 14.14286F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.Location = new System.Drawing.Point(988, 905);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(138, 69);
            this.btnDelete.TabIndex = 41;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.Indigo;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Segoe Marker", 14.14286F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.Location = new System.Drawing.Point(840, 905);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(114, 69);
            this.btnAdd.TabIndex = 40;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightGray;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Location = new System.Drawing.Point(3, 563);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(157, 32);
            this.panel2.TabIndex = 36;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(label4);
            this.panel1.Controls.Add(label3);
            this.panel1.Controls.Add(label5);
            this.panel1.Controls.Add(label2);
            this.panel1.Location = new System.Drawing.Point(840, 192);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(140, 597);
            this.panel1.TabIndex = 48;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.Indigo;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Segoe Marker", 14.14286F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(1666, 905);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(126, 69);
            this.btnClose.TabIndex = 44;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // genderComboBox
            // 
            this.genderComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appointmentBindingSource, "Gender", true));
            this.genderComboBox.Font = new System.Drawing.Font("Segoe Marker", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.genderComboBox.FormattingEnabled = true;
            this.genderComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "N/A"});
            this.genderComboBox.Location = new System.Drawing.Point(489, 352);
            this.genderComboBox.Name = "genderComboBox";
            this.genderComboBox.Size = new System.Drawing.Size(250, 41);
            this.genderComboBox.TabIndex = 49;
            this.genderComboBox.SelectedIndexChanged += new System.EventHandler(this.genderComboBox_SelectedIndexChanged);
            this.genderComboBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KP4);
            // 
            // area_CodeComboBox
            // 
            this.area_CodeComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appointmentBindingSource, "Area_Code", true));
            this.area_CodeComboBox.Font = new System.Drawing.Font("Segoe Marker", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.area_CodeComboBox.FormattingEnabled = true;
            this.area_CodeComboBox.Items.AddRange(new object[] {
            "+93",
            "+1",
            "+54",
            "+61",
            "+43",
            "+32",
            "+55",
            "+95",
            "+34",
            "+56",
            "+86",
            "+61",
            "+53",
            "+45",
            "+56",
            "+20",
            "+44",
            "+33",
            "+49",
            "+30",
            "+57",
            "+44",
            "+36",
            "+91",
            "+62",
            "+98",
            "+44",
            "+39",
            "+7",
            "+60"});
            this.area_CodeComboBox.Location = new System.Drawing.Point(487, 459);
            this.area_CodeComboBox.MaxLength = 3;
            this.area_CodeComboBox.Name = "area_CodeComboBox";
            this.area_CodeComboBox.Size = new System.Drawing.Size(250, 41);
            this.area_CodeComboBox.TabIndex = 50;
            this.area_CodeComboBox.SelectedIndexChanged += new System.EventHandler(this.area_CodeComboBox_SelectedIndexChanged);
            // 
            // marital_StatusComboBox
            // 
            this.marital_StatusComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appointmentBindingSource, "Marital_Status", true));
            this.marital_StatusComboBox.Font = new System.Drawing.Font("Segoe Marker", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.marital_StatusComboBox.FormattingEnabled = true;
            this.marital_StatusComboBox.Items.AddRange(new object[] {
            "Single",
            "Married",
            "Divorced",
            "Separated",
            "Widowed"});
            this.marital_StatusComboBox.Location = new System.Drawing.Point(487, 566);
            this.marital_StatusComboBox.Name = "marital_StatusComboBox";
            this.marital_StatusComboBox.Size = new System.Drawing.Size(250, 41);
            this.marital_StatusComboBox.TabIndex = 51;
            this.marital_StatusComboBox.SelectedIndexChanged += new System.EventHandler(this.marital_StatusComboBox_SelectedIndexChanged);
            this.marital_StatusComboBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KP5);
            // 
            // comboBoxCountry1
            // 
            this.comboBoxCountry1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appointmentBindingSource, "Country", true));
            this.comboBoxCountry1.Font = new System.Drawing.Font("Segoe Marker", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxCountry1.FormattingEnabled = true;
            this.comboBoxCountry1.Items.AddRange(new object[] {
            "Bangladesh",
            "Brazil",
            "Canada",
            "Australia",
            "France",
            "India",
            "Japan",
            "Pakistan",
            "United Kingdom",
            "USA"});
            this.comboBoxCountry1.Location = new System.Drawing.Point(487, 726);
            this.comboBoxCountry1.Name = "comboBoxCountry1";
            this.comboBoxCountry1.Size = new System.Drawing.Size(250, 41);
            this.comboBoxCountry1.TabIndex = 52;
            this.comboBoxCountry1.SelectedIndexChanged += new System.EventHandler(this.comboBoxCountry1_SelectedIndexChanged);
            this.comboBoxCountry1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KP7);
            // 
            // comboBoxstate1
            // 
            this.comboBoxstate1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appointmentBindingSource, "State", true));
            this.comboBoxstate1.Font = new System.Drawing.Font("Segoe Marker", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxstate1.FormattingEnabled = true;
            this.comboBoxstate1.Items.AddRange(new object[] {
            "Barisal",
            "Chittagong",
            "Dhaka",
            "Khulna",
            "Rajshahi",
            "ROngpur",
            "Federal",
            "Ceara",
            "Bahia",
            "Amapa",
            "Amazonas",
            "Acre",
            "Columbia",
            "Alberta",
            "Manitoba",
            "Ontario",
            "Queensland",
            "Victori",
            "Tasmania",
            "South Austrailia",
            "Sydney",
            "Lorraine",
            "Picardie",
            "Alsace",
            "Haute Normandie",
            "Bourgogne",
            "Andhra Pradesh",
            "Arunachal Pradesh",
            "Assam",
            "Bihar",
            "Chhattisgarh",
            "Goa",
            "Gujarat",
            "Haryana",
            "Himachal Pradesh",
            "Jammu and Kashmir",
            "Jharkhand",
            "Karnataka",
            "Kerala",
            "Madhya Pradesh",
            "Maharahstra",
            "Manipur",
            "Meghalaya",
            "Mizoram",
            "Nagaland",
            "Odhisa",
            "Punjab",
            "Rajastan",
            "Sikkim",
            "Tamil Nadu",
            "Telangana",
            "Tripura",
            "Alabama",
            "Alaska",
            "Arizon",
            "Arkansas",
            "California",
            "Colorado",
            "Connecticut",
            "Delaware",
            "Florida",
            "Shizuoka",
            "Fukuoka",
            "Hokkaido",
            "Saitama",
            "Hyogo",
            "Chiba",
            "Aichi",
            "Kanagawa",
            "Punjab",
            "Sindh",
            "Khyber Pakhtunkhwa",
            "Balochistan",
            "London",
            "West Midlands",
            "Greater Manchester",
            "West Yorkshire",
            "South Yorkshire",
            "Hampshire",
            "Surrey",
            "Merseyside"});
            this.comboBoxstate1.Location = new System.Drawing.Point(487, 780);
            this.comboBoxstate1.Name = "comboBoxstate1";
            this.comboBoxstate1.Size = new System.Drawing.Size(250, 41);
            this.comboBoxstate1.TabIndex = 53;
            this.comboBoxstate1.SelectedIndexChanged += new System.EventHandler(this.comboBoxstate1_SelectedIndexChanged);
            this.comboBoxstate1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KP6);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // btnX
            // 
            this.btnX.BackColor = System.Drawing.Color.Transparent;
            this.btnX.Font = new System.Drawing.Font("Britannic Bold", 11.14286F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnX.Location = new System.Drawing.Point(1933, 1);
            this.btnX.Name = "btnX";
            this.btnX.Size = new System.Drawing.Size(75, 44);
            this.btnX.TabIndex = 63;
            this.btnX.Text = "X";
            this.btnX.UseVisualStyleBackColor = false;
            this.btnX.Click += new System.EventHandler(this.btnX_Click);
            // 
            // btnMinimise
            // 
            this.btnMinimise.BackColor = System.Drawing.Color.Transparent;
            this.btnMinimise.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 11.14286F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMinimise.Location = new System.Drawing.Point(1858, 1);
            this.btnMinimise.Name = "btnMinimise";
            this.btnMinimise.Size = new System.Drawing.Size(75, 44);
            this.btnMinimise.TabIndex = 62;
            this.btnMinimise.Text = "--";
            this.btnMinimise.UseVisualStyleBackColor = false;
            this.btnMinimise.Click += new System.EventHandler(this.btnMinimise_Click);
            // 
            // appointment1BindingSource
            // 
            this.appointment1BindingSource.DataMember = "Appointment1";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1924, 1044);
            this.Controls.Add(this.btnX);
            this.Controls.Add(this.btnMinimise);
            this.Controls.Add(stateLabel);
            this.Controls.Add(this.comboBoxstate1);
            this.Controls.Add(countryLabel);
            this.Controls.Add(this.comboBoxCountry1);
            this.Controls.Add(marital_StatusLabel);
            this.Controls.Add(this.marital_StatusComboBox);
            this.Controls.Add(area_CodeLabel);
            this.Controls.Add(this.area_CodeComboBox);
            this.Controls.Add(genderLabel);
            this.Controls.Add(this.genderComboBox);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.panel1);
            this.Controls.Add(label1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.appointmentDataGridView);
            this.Controls.Add(appointment_Ref_NoLabel);
            this.Controls.Add(this.appointment_Ref_NoTextBox);
            this.Controls.Add(first_NmaeLabel);
            this.Controls.Add(this.first_NmaeTextBox);
            this.Controls.Add(middle_NameLabel);
            this.Controls.Add(this.middle_NameTextBox);
            this.Controls.Add(last_NameLabel);
            this.Controls.Add(this.last_NameTextBox);
            this.Controls.Add(e_mail_AddressLabel);
            this.Controls.Add(this.e_mail_AddressTextBox);
            this.Controls.Add(date_of_BirthLabel);
            this.Controls.Add(this.date_of_BirthDateTimePicker);
            this.Controls.Add(contact_NoLabel);
            this.Controls.Add(this.contact_NoTextBox);
            this.Controls.Add(addressLabel);
            this.Controls.Add(this.addressTextBox);
            this.Controls.Add(postal_CodeLabel);
            this.Controls.Add(this.postal_CodeTextBox);
            this.Controls.Add(cityLabel);
            this.Controls.Add(this.cityTextBox);
            this.Controls.Add(doctor_NameLabel);
            this.Controls.Add(this.doctor_NameTextBox);
            this.Controls.Add(doctor_Ref_NoLabel);
            this.Controls.Add(this.doctor_Ref_NoTextBox);
            this.Controls.Add(date_TimeLabel);
            this.Controls.Add(this.date_TimeDateTimePicker);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form2";
            this.Text = "Form2";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.hospitalDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appointmentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appointmentDataGridView)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appointment1BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private HospitalDataSet hospitalDataSet;
        private System.Windows.Forms.BindingSource appointmentBindingSource;
        private HospitalDataSetTableAdapters.AppointmentTableAdapter appointmentTableAdapter;
        private HospitalDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TextBox appointment_Ref_NoTextBox;
        private System.Windows.Forms.TextBox first_NmaeTextBox;
        private System.Windows.Forms.TextBox middle_NameTextBox;
        private System.Windows.Forms.TextBox last_NameTextBox;
        private System.Windows.Forms.TextBox e_mail_AddressTextBox;
        private System.Windows.Forms.DateTimePicker date_of_BirthDateTimePicker;
        private System.Windows.Forms.TextBox contact_NoTextBox;
        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.TextBox postal_CodeTextBox;
        private System.Windows.Forms.TextBox cityTextBox;
        private System.Windows.Forms.TextBox doctor_NameTextBox;
        private System.Windows.Forms.TextBox doctor_Ref_NoTextBox;
        private System.Windows.Forms.DateTimePicker date_TimeDateTimePicker;
        private System.Windows.Forms.DataGridView appointmentDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.BindingSource appointment1BindingSource;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ComboBox genderComboBox;
        private System.Windows.Forms.ComboBox area_CodeComboBox;
        private System.Windows.Forms.ComboBox marital_StatusComboBox;
        private System.Windows.Forms.ComboBox comboBoxCountry1;
        private System.Windows.Forms.ComboBox comboBoxstate1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Button btnX;
        private System.Windows.Forms.Button btnMinimise;
    }
}