﻿namespace Hospital_Management_System_Application {
    
    
    public partial class HospitalDataSet {
    }
}

namespace Hospital_Management_System_Application.HospitalDataSetTableAdapters {
    
    
    public partial class AppointmentTableAdapter {
    }
}
